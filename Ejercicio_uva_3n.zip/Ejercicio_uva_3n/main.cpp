#include <iostream>

using namespace std;


void ciclos(int i, int j)
{
    int contador1 = 0;

    for (int f = i; f <= j ; f++)
    {
        int contador2 = 0;
        int numero = f;

        while (numero != 1)
        {
            if (numero % 2 == 1)
            {
                numero = (numero*3)+1;
                contador2++;
            }
            else{
                numero = numero /2;
                contador2++;
            }
        }
        contador2++;
        if(contador2 > contador1)
        {
            contador1 = contador2;
        }

    }
    cout << i << " " << j << " " << contador1 << " ";

}

int main() {

    int i, j;

    cin >> i;
    cin >> j;

ciclos(i,j);

    return 0;
}
